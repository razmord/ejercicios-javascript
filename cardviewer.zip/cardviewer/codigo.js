window.onload = function(){
    document.getElementById('button1').addEventListener('click', loadLuna);
    document.getElementById('button2').addEventListener('click', loadRitual);
    /*Esta funcion carga las cartas del arquetipo Lunalight*/ 
    function loadLuna() {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', 'luna.json', true);

        xhr.onload = function() {
            if (this.status == 200) {
                console.log("Datos obtenidos:..." + this.responseText);
                var cards = JSON.parse(this.responseText);
                console.log("Datos obtenidos despues del PARSE:..." + cards);

                var output = '<ul>';
                /*Se crea un boton para cada carta */
                for (var i in cards) {
                    output += 
                    '<li><button class="carta" value="'+i+' name="luna.json">' + cards[i].name + '</button></li>'
                        ;/*Se pasa el id y el json del que proviene en cada carta */
                }
                output +='</ul>';

                document.getElementById('decklist').innerHTML = output;
                /*Se añade un EventListener a cada carta para poder mostralas luego*/
                var elementsArray = document.querySelectorAll('button.carta');

                elementsArray.forEach(function(elem) {
                    elem.addEventListener('click', loadCard);
                });

            }
        }

        xhr.send();
    }
     /*Esta funcion carga las cartas del arquetipo Ritual*/ 
    function loadRitual() {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', 'ritual.json', true);

        xhr.onload = function() {
            if (this.status == 200) {
                console.log("Datos obtenidos:..." + this.responseText);
                var cards = JSON.parse(this.responseText);
                console.log("Datos obtenidos despues del PARSE:..." + cards);

                var output = '<ul>';
                /*Se crea un boton para cada carta */
                for (var i in cards) {
                    output += 
                        '<li><button class="carta" value="'+i+' name="ritual.json">' + cards[i].name + '</button></li>'
                        ;/*Se pasa el id y el json del que proviene en cada carta */
                }
                output +='</ul>';

                document.getElementById('decklist').innerHTML = output;
                /*Se añade un EventListener a cada carta para poder mostralas luego*/
                var elementsArray = document.querySelectorAll('button.carta');
                elementsArray.forEach(function(elem) {
                    elem.addEventListener('click', loadCard);
                    console.log("Añadiendo addEventListener");
                });
            }
        }

        xhr.send();
    }
/*Esta funcion carga las cartas individuales*/ 
function loadCard() {
    console.log("Cargando carta desde "+this.name);
    var xhr = new XMLHttpRequest();
    xhr.open('GET', this.name, true);

    xhr.onload = function() {
        if (this.status == 200) {
            console.log("Datos de la carta obtenidos:..." + this.responseText);
            var cards = JSON.parse(this.responseText);
            console.log("Datos de la carta obtenidos despues del PARSE:..." + cards);
        }
    }
    xhr.send();
}
};